<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'LoginController@index')->name('login');
Route::post('/login', 'LoginController@login');

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/logout', 'LoginController@logout')->name('logout');

    Route::get('/GPRO001', 'GPRO001@index');

    Route::get('/GPRO002', 'GPRO002@index');

    Route::get('/GPRO003', 'GPRO003@index');
    Route::get('/GPRO003/getData', 'GPRO003@getData');
    Route::get('/GPRO003/create', 'GPRO003@create');
    Route::post('/GPRO003/store', 'GPRO003@store');
    Route::get('/GPRO003/edit/{id}', 'GPRO003@edit');
    Route::patch('/GPRO003/update/{id}', 'GPRO003@update');
    Route::get('/GPRO003/delete/{id}', 'GPRO003@destroy');

    Route::get('/GPRO004', 'GPRO004@index');
    Route::get('/GPRO004/create', 'GPRO004@create');
    Route::get('/GPRO004/getData', 'GPRO004@getData');
    Route::get('/GPRO004/edit/{id}', 'GPRO004@edit');
    Route::get('/GPRO004/delete/{id}', 'GPRO004@destroy');
    Route::get('/GPRO004/delete-job-desc/{id}/{uniqueId}', 'GPRO004@deleteJobDesc');
    Route::get('/GPRO004/delete-education/{id}/{uniqueId}', 'GPRO004@deleteEducation');
    Route::get('/GPRO004/delete-training/{id}/{uniqueId}', 'GPRO004@deleteTraining');
    Route::get('/GPRO004/delete-license/{id}/{uniqueId}', 'GPRO004@deleteLicense');
    Route::get('/GPRO004/delete-experience/{id}/{uniqueId}', 'GPRO004@deleteExperience');

    Route::post('/GPRO004/store', 'GPRO004@store')->name('GPRO004/store');
    Route::post('/GPRO004/next', 'GPRO004@next');
    Route::post('/GPRO004/add-job-desc', 'GPRO004@addJobDesc')->name('add-job-desc');
    Route::post('/GPRO004/add-education', 'GPRO004@addEducation')->name('add-education');
    Route::post('/GPRO004/add-training', 'GPRO004@addTraining')->name('add-training');
    Route::post('/GPRO004/add-license', 'GPRO004@addLicense')->name('add-license');
    Route::post('/GPRO004/add-experience', 'GPRO004@addExperience')->name('add-experience');

    Route::get('/GPRO007', 'GPRO007@index');
    Route::post('/GPRO007/export', 'GPRO007@export')->name('GPRO007/export');
    Route::post('/GPRO007/import', 'GPRO007@import')->name('GPRO007/import');

    Route::get('/GPRO010', 'GPRO010@index');
    Route::get('/GPRO010/getData', 'GPRO010@getData');
    Route::get('/GPRO010/create', 'GPRO010@create');
    Route::post('/GPRO010/store', 'GPRO010@store');
    Route::get('/GPRO010/edit/{id}', 'GPRO010@edit');
    Route::patch('/GPRO010/update/{id}', 'GPRO010@update');
    Route::get('/GPRO010/delete/{id}', 'GPRO010@destroy');

    Route::get('/GPRO005', 'GPRO005@index');
    Route::get('/GPRO005/getData', 'GPRO005@getData');
    Route::post('/GPRO005/import', 'GPRO005@import')->name('GPRO005/import');

    Route::get('/GPRO006', 'GPRO006@index');
    Route::get('/GPRO006/getData', 'GPRO006@getData');
    Route::get('/GPRO006/export', 'GPRO006@export')->name('GPRO006/export');
    Route::post('/GPRO006/import', 'GPRO006@import')->name('GPRO006/import');
});
