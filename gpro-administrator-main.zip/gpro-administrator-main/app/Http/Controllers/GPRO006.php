<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;
use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;
use Box\Spout\Writer\Common\Creator\WriterEntityFactory;

class GPRO006 extends Controller
{
    public function index()
    {
        return view('gpro006.index');
    }

    public function getData()
    {
        $this->changeConnection(getenv('DB_GPRO'));
        $data = DB::select("select a.id, a.description, b.description as category 
        from tbl_subcategories as a
        join tbl_categories as b on b.id = a.category_id
        order by b.description asc
        ");
        $this->changeConnection();
        return DataTables::of($data)->make(true);
    }

    public function import(Request $request)
    {
        $file = $request->file;
        $reader = ReaderEntityFactory::createXLSXReader();
        $reader->open($file);
        foreach ($reader->getSheetIterator() as $k => $sheet) {
            if ($k === 2) {
                foreach ($sheet->getRowIterator() as $key => $row) {
                    if ($key !== 1) {
                        $cells = $row->getCells();
                        $data[] = [
                            'category_id' => $cells[0]->getValue(),
                            'description' => $cells[1]->getValue()
                        ];
                    }
                }
            }
        }

        $chunk = array_chunk($data, 1000);
        $this->changeConnection(getenv('DB_GPRO'));
        foreach ($chunk as $item) {
            $this->insert('tbl_subcategories', $item);
        }
        $this->changeConnection();
        $reader->close();
        Session::flash('success', 'Berhasil Import Data');
        return redirect('GPRO006');
    }

    public function export()
    {
        $this->changeConnection(getenv('DB_GPRO'));
        $categories = DB::table('tbl_categories')->select(['id', 'description'])->get();
        $writer = WriterEntityFactory::createXLSXWriter();
        $fileName = "TemplateSubCategory.xlsx";
        $writer->openToBrowser($fileName);
        $header = [
            WriterEntityFactory::createCell('ID Kategori'),
            WriterEntityFactory::createCell('Deskripsi')
        ];
        $writer->getCurrentSheet()->setName('Data');
        $singleRow = WriterEntityFactory::createRow($header);
        $writer->addRow($singleRow);

        $all_data = [];
        foreach ($categories as $key => $value) {
            $data = [
                WriterEntityFactory::createCell($value->id),
                WriterEntityFactory::createCell($value->description)
            ];
            array_push($all_data, WriterEntityFactory::createRow($data));
        }
        $writer->addRows($all_data);

        $header = [
            WriterEntityFactory::createCell('category_id'),
            WriterEntityFactory::createCell('description')
        ];

        $writer->addNewSheetAndMakeItCurrent();
        $writer->getCurrentSheet()->setName('Contoh Template');
        $singleRow = WriterEntityFactory::createRow($header);
        $writer->addRow($singleRow);

        $data = [
            WriterEntityFactory::createCell('1'),
            WriterEntityFactory::createCell('Lorem Ipsum')
        ];
        $singleRow = WriterEntityFactory::createRow($data);
        $writer->addRow($singleRow);

        $writer->close();
    }
}
