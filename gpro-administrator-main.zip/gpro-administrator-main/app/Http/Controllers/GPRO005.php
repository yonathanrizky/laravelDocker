<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;
use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;

class GPRO005 extends Controller
{
    public function index()
    {
        return view('gpro005.index');
    }

    public function getData()
    {
        $this->changeConnection(getenv('DB_GPRO'));
        $data = DB::select("select id, description from tbl_categories");
        $this->changeConnection();
        return DataTables::of($data)->make(true);
    }

    public function import(Request $request)
    {
        $file = $request->file;
        $reader = ReaderEntityFactory::createXLSXReader();
        $reader->open($file);
        foreach ($reader->getSheetIterator() as $k => $sheet) {
            if ($k === 1) {
                foreach ($sheet->getRowIterator() as $key => $row) {
                    if ($key !== 1) {
                        $cells = $row->getCells();
                        $data[] = [
                            'description' => $cells[0]->getValue()
                        ];
                    }
                }
            }
        }

        $chunk = array_chunk($data, 1000);
        $this->changeConnection(getenv('DB_GPRO'));
        foreach ($chunk as $item) {
            $this->insert('tbl_categories', $item);
        }
        $this->changeConnection();
        $reader->close();
        Session::flash('success', 'Berhasil Import Data');
        return redirect('GPRO005');
    }
}
