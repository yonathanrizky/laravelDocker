<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;
use Box\Spout\Writer\Common\Creator\WriterEntityFactory;

class GPRO007 extends Controller
{
    public function index()
    {
        return view('gpro007.index');
    }

    public function export(Request $request)
    {
        $type = $request->type;
        if ($type == 'career') {
            $this->changeConnection(getenv('DB_GPRO'));
            $subCategories = DB::table('tbl_subcategories as a')
                ->select('a.id', DB::raw("concat(b.description, ' - ', a.description) as description"))
                ->join('tbl_categories as b', 'b.id', '=', 'a.category_id')
                ->orderBy('b.description', 'asc')
                ->get();
            $this->changeConnection();
            $writer = WriterEntityFactory::createXLSXWriter();
            $fileName = "TemplateCareerAdvisor.xlsx";
            $writer->openToBrowser($fileName);
            $header = [
                WriterEntityFactory::createCell('ID Kategori'),
                WriterEntityFactory::createCell('Deskripsi')
            ];
            $writer->getCurrentSheet()->setName('Data');
            $singleRow = WriterEntityFactory::createRow($header);
            $writer->addRow($singleRow);

            $all_data = [];
            foreach ($subCategories as $key => $value) {
                $data = [
                    WriterEntityFactory::createCell($value->id),
                    WriterEntityFactory::createCell($value->description)
                ];
                array_push($all_data, WriterEntityFactory::createRow($data));
            }
            $writer->addRows($all_data);

            $header = [
                WriterEntityFactory::createCell('sub_categories_id'),
                WriterEntityFactory::createCell('description'),
                WriterEntityFactory::createCell('become_desc'),
                WriterEntityFactory::createCell('sallary_start'),
                WriterEntityFactory::createCell('sallary_end'),
                WriterEntityFactory::createCell('photo_banner')
            ];

            $writer->addNewSheetAndMakeItCurrent();
            $writer->getCurrentSheet()->setName('Contoh Template');
            $singleRow = WriterEntityFactory::createRow($header);
            $writer->addRow($singleRow);

            $data = [
                WriterEntityFactory::createCell('1'),
                WriterEntityFactory::createCell('Lorem Ipsum'),
                WriterEntityFactory::createCell('Lorem Ipsum'),
                WriterEntityFactory::createCell('100000'),
                WriterEntityFactory::createCell('200000'),
                WriterEntityFactory::createCell('https://picture.com')
            ];
            $singleRow = WriterEntityFactory::createRow($data);
            $writer->addRow($singleRow);

            $writer->close();
        } else {
            $writer = WriterEntityFactory::createXLSXWriter();
            $fileName = "TemplateDetailCareerAdvisor.xlsx";
            $writer->openToBrowser($fileName);
            $header = [
                WriterEntityFactory::createCell('ID Kategori'),
                WriterEntityFactory::createCell('ID Career Advisor'),
                WriterEntityFactory::createCell('Keterangan')
            ];
            $writer->getCurrentSheet()->setName('Data');
            $singleRow = WriterEntityFactory::createRow($header);
            $writer->addRow($singleRow);

            $getData = DB::table('tbl_career_advisors')->select(['sub_categories_id', 'id', 'description'])->get();
            $all_data = [];
            foreach ($getData as $key => $value) {
                $data = [
                    WriterEntityFactory::createCell($value->sub_categories_id),
                    WriterEntityFactory::createCell($value->id),
                    WriterEntityFactory::createCell($value->description)
                ];
                array_push($all_data, WriterEntityFactory::createRow($data));
            }
            $writer->addRows($all_data);

            $header = [
                WriterEntityFactory::createCell('career_advisor_id'),
                WriterEntityFactory::createCell('description'),
            ];

            $sheetName = ['Job Desc', 'Pendidikan', 'Training', 'Lisensi', 'Experience'];
            foreach ($sheetName as $key => $value) {
                $writer->addNewSheetAndMakeItCurrent();
                $writer->getCurrentSheet()->setName($value);
                $singleRow = WriterEntityFactory::createRow($header);
                $writer->addRow($singleRow);

                $data = [
                    WriterEntityFactory::createCell('1'),
                    WriterEntityFactory::createCell('Lorem Ipsum')
                ];
                $singleRow = WriterEntityFactory::createRow($data);
                $writer->addRow($singleRow);
            }
            $writer->close();
        }
    }

    public function import(Request $request)
    {
        $type = $request->type;
        $file = $request->file;
        if ($type == 'career') {
            $reader = ReaderEntityFactory::createXLSXReader();
            $reader->open($file);
            foreach ($reader->getSheetIterator() as $k => $sheet) {
                if ($k !== 1) {
                    foreach ($sheet->getRowIterator() as $key => $row) {
                        if ($key !== 1) {
                            $cells = $row->getCells();
                            $data[] = [
                                'sub_categories_id' => $cells[0]->getValue(),
                                'description' => $cells[1]->getValue(),
                                'become_desc' => $cells[2]->getValue(),
                                'sallary_start' => $cells[3]->getValue(),
                                'sallary_end' => $cells[4]->getValue(),
                                'photo_banner' => $cells[5]->getValue()
                            ];
                        }
                    }
                }
            }

            $chunk = array_chunk($data, 1000);
            foreach ($chunk as $item) {
                $this->insert('tbl_career_advisors', $item);
            }
            $reader->close();
            Session::flash('success', 'Berhasil Import Data');
            return redirect('GPRO007');
        } else {
            $reader = ReaderEntityFactory::createXLSXReader();
            $reader->open($file);
            foreach ($reader->getSheetIterator() as $k => $sheet) {

                if ($k !== 1) {
                    $data = [];
                    foreach ($sheet->getRowIterator() as $key => $row) {
                        if ($key !== 1) {
                            $cells = $row->getCells();
                            array_push($data, [
                                'career_advisor_id' => $cells[0]->getValue(),
                                'description' => $cells[1]->getValue()
                            ]);
                        }
                    }

                    $chunk = array_chunk($data, 1000);
                    foreach ($chunk as $item) {
                        if ($k === 2) {
                            $this->insert('tbl_job_desc', $item);
                        } else if ($k === 3) {
                            $this->insert('tbl_education_advisors', $item);
                        } else if ($k === 4) {
                            $this->insert('tbl_training_advisors', $item);
                        } else if ($k === 5) {
                            $this->insert('tbl_license_advisors', $item);
                        } else if ($k === 6) {
                            $this->insert('tbl_experience_advisors', $item);
                        }
                    }
                }
            }

            $reader->close();
            Session::flash('success', 'Berhasil Import Data');
            return redirect('GPRO007');
        }
    }
}
