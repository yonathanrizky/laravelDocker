<?php

namespace App\Http\Controllers;

use App\CareerAdvisor;
use App\TempCareerAdvisor;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class GPRO004 extends Controller
{
    public function index()
    {
        return view('gpro004.index');
    }

    public function getData()
    {
        $data = DB::select("select id, description from tbl_career_advisors");
        return DataTables::of($data)->make(true);
    }

    public function create()
    {
        $uniqueId = (int)(microtime(true) * 1000);
        $subCategories = $this->getSubCategories();
        $activity = 'C';
        return view('gpro004.create', compact(['subCategories', 'uniqueId', 'activity']));
    }

    public function next(Request $request)
    {
        $uniqueId = $request->uniqueId;

        $tempCareer = new TempCareerAdvisor();
        $tempCareer->sub_categories_id = $request->sub_categories_id;
        $tempCareer->description = $request->description;
        $tempCareer->unique_id = $request->uniqueId;
        $tempCareer->become_desc = $request->become_desc;
        $tempCareer->sallary_start = $request->sallary_start;
        $tempCareer->sallary_end = $request->sallary_end;
        $tempCareer->photo_banner = $request->photo_banner;
        try {
            $tempCareer->save();
        } catch (\Throwable $e) {
            if ($e->getCode() == '23505') {
                $this->updateWhere('temp_career_advisor', [
                    'description' => $request->description,
                    'become_desc' => $request->become_desc,
                    'sallary_start' => $request->sallary_start,
                    'sallary_end' => $request->sallary_end,
                    'photo_banner' => $request->photo_banner,
                ], ['unique_id' => $uniqueId]);
            } else {
                dd([$e->getCode(), $e->getMessage()]);
            }
        }
        $tempCareer = TempCareerAdvisor::where('unique_id', $uniqueId)->first();
        $jobDesc = $tempCareer ? json_decode($tempCareer->job_desc, true) : [];
        $education = $tempCareer ? json_decode($tempCareer->education, true) : [];
        $training = $tempCareer ? json_decode($tempCareer->training, true) : [];
        $license = $tempCareer ? json_decode($tempCareer->license, true) : [];
        $experience = $tempCareer ? json_decode($tempCareer->experience, true) : [];
        return view('gpro004.partials.second_page', compact(['uniqueId', 'jobDesc', 'education', 'training', 'license', 'experience']));
    }

    public function store(Request $request)
    {
        $uniqueId = $request->uniqueId;
        $tempCareer = TempCareerAdvisor::where('unique_id', $uniqueId)->first();
        $career_advisor_id = $tempCareer->career_advisor_id;
        if ($career_advisor_id) {
            $career = CareerAdvisor::find($career_advisor_id);
        } else {
            $career = new CareerAdvisor();
        }

        $career->sub_categories_id = $tempCareer->sub_categories_id;
        $career->description = $tempCareer->description;
        $career->become_desc = $tempCareer->become_desc;
        $career->sallary_start = $tempCareer->sallary_start;
        $career->sallary_end = $tempCareer->sallary_end;
        $career->photo_banner = $tempCareer->photo_banner;
        try {
            if ($career_advisor_id) {
                $career->update();
                DB::table('tbl_job_desc')->where('career_advisor_id', $career_advisor_id)->delete();
                DB::table('tbl_education_advisors')->where('career_advisor_id', $career_advisor_id)->delete();
                DB::table('tbl_training_advisors')->where('career_advisor_id', $career_advisor_id)->delete();
                DB::table('tbl_license_advisors')->where('career_advisor_id', $career_advisor_id)->delete();
                DB::table('tbl_experience_advisors')->where('career_advisor_id', $career_advisor_id)->delete();
            } else {
                $career->save();
            }

            $id = $career->id;
            $jobDesc = $this->filterArr(json_decode($tempCareer->job_desc, true), 'description', $id);
            $education = $this->filterArr(json_decode($tempCareer->education, true), 'description', $id);
            $training = $this->filterArr(json_decode($tempCareer->training, true), 'description', $id);
            $license = $this->filterArr(json_decode($tempCareer->license, true), 'description', $id);
            $experience = $this->filterArr(json_decode($tempCareer->experience, true), 'description', $id);
            DB::table('tbl_job_desc')->insert($jobDesc);
            DB::table('tbl_education_advisors')->insert($education);
            DB::table('tbl_training_advisors')->insert($training);
            DB::table('tbl_license_advisors')->insert($license);
            DB::table('tbl_experience_advisors')->insert($experience);
            $tempCareer->delete();
        } catch (\Throwable $e) {
            DB::rollBack();
            dd($e);
        }

        return redirect('/GPRO004');
    }

    public function edit($id)
    {
        $uniqueId = (int)(microtime(true) * 1000);
        $subCategories = $this->getSubCategories();
        $data = CareerAdvisor::find($id);
        $activity = 'U';

        $tempCareer = new TempCareerAdvisor();
        $tempCareer->career_advisor_id = $data->id;
        $tempCareer->sub_categories_id = $data->sub_categories_id;
        $tempCareer->description = $data->description;
        $tempCareer->unique_id = $uniqueId;
        $tempCareer->become_desc = $data->become_desc;
        $tempCareer->sallary_start = $data->sallary_start;
        $tempCareer->sallary_end = $data->sallary_end;
        $tempCareer->photo_banner = $data->photo_banner;

        $jobDesc = DB::table('tbl_job_desc')->select('id', 'description')->where('career_advisor_id', $id)->get();
        $dataJob = $this->toJson($jobDesc);
        $training = DB::table('tbl_training_advisors')->select('id', 'description')->where('career_advisor_id', $id)->get();
        $dataTraning = $this->toJson($training);
        $education = DB::table('tbl_education_advisors')->select('id', 'description')->where('career_advisor_id', $id)->get();
        $dataEducation = $this->toJson($education);
        $license = DB::table('tbl_license_advisors')->select('id', 'description')->where('career_advisor_id', $id)->get();
        $dataLicense = $this->toJson($license);
        $experience = DB::table('tbl_experience_advisors')->select('id', 'description')->where('career_advisor_id', $id)->get();
        $dataExperience = $this->toJson($experience);

        $tempCareer->job_desc = json_encode($dataJob);
        $tempCareer->education = json_encode($dataEducation);
        $tempCareer->training = json_encode($dataTraning);
        $tempCareer->license = json_encode($dataLicense);
        $tempCareer->experience = json_encode($dataExperience);
        $tempCareer->save();
        return view('gpro004.create', compact(['subCategories', 'uniqueId', 'data', 'activity', 'id']));
    }

    public function addJobDesc(Request $request)
    {
        return $this->addData($request, 'job_desc');
    }

    public function deleteJobDesc($id, $uniqueId)
    {
        return $this->deleteData($id, $uniqueId, 'job_desc');
    }

    public function addEducation(Request $request)
    {
        return $this->addData($request, 'education');
    }

    public function deleteEducation($id, $uniqueId)
    {
        return $this->deleteData($id, $uniqueId, 'education');
    }

    public function addTraining(Request $request)
    {
        return $this->addData($request, 'training');
    }

    public function deleteTraining($id, $uniqueId)
    {
        return $this->deleteData($id, $uniqueId, 'training');
    }

    public function addLicense(Request $request)
    {
        return $this->addData($request, 'license');
    }

    public function deleteLicense($id, $uniqueId)
    {
        return $this->deleteData($id, $uniqueId, 'license');
    }

    public function addExperience(Request $request)
    {
        return $this->addData($request, 'experience');
    }

    public function deleteExperience($id, $uniqueId)
    {
        return $this->deleteData($id, $uniqueId, 'experience');
    }

    private function addData($request, $value)
    {
        $uniqueId = $request->uniqueId;
        $tempCareer = TempCareerAdvisor::where('unique_id', $uniqueId)->first();
        $descr = $tempCareer->$value;
        $descr =  $descr ? json_decode($descr, true) : [];
        array_push($descr, [
            'id' => count($descr) + 1,
            'description' => $request->description
        ]);
        $tempCareer->$value = json_encode($descr);
        $tempCareer->save();

        return $uniqueId;
    }

    private function deleteData($id, $uniqueId, $field)
    {
        $tempCareer = TempCareerAdvisor::where('unique_id', $uniqueId)->first();
        $descr = $tempCareer->$field;
        $descr = json_decode($descr, true);
        foreach ($descr as $key => $value) {
            if ($value['id'] == $id) {
                unset($descr[$key]);
            }
        }
        $tempCareer->$field = json_encode($descr);
        $tempCareer->save();

        return $uniqueId;
    }

    private function filterArr($array, $key, $id)
    {
        $data = [];
        if ($array)
            foreach ($array as $value) {
                array_push($data, [$key => $value[$key], 'career_advisor_id' => $id]);
            }
        return $data;
    }

    public function getSubCategories()
    {
        $this->changeConnection(getenv('DB_GPRO'));
        $subCategories = DB::table('tbl_subcategories as a')
            ->select('a.id', DB::raw("concat(b.description, ' - ', a.description) as description"))
            ->join('tbl_categories as b', 'b.id', '=', 'a.category_id')
            ->orderBy('b.description', 'asc')
            ->get();
        $this->changeConnection();
        return $subCategories;
    }

    function toJson($data)
    {
        $result = [];
        foreach ($data as $key => $value) {
            array_push($result, [
                'id' => count($result) + 1,
                'description' => $value->description
            ]);
        }
        return $result;
    }

    public function destroy($id)
    {
        $data = CareerAdvisor::find($id);
        $data->delete();
        Session::flash('delete', 'Data Berhasil Dihapus');
        return redirect('GPRO004');
    }
}
