<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class GPRO002 extends Controller
{
    public function index()
    {
        $profile = User::where('id',Session::get('id'))->first();
        return view('gpro002.index');
    }
}
