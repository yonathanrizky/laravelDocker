<?php

namespace App\Http\Controllers;

use App\Menu;
use Illuminate\Http\Request;

class GPRO001 extends Controller
{
    public function index()
    {
        $menu = new Menu();
        return view('gpro001.index');
    }
}
