<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Jenssegers\Agent\Agent;

class LoginController extends Controller
{
    public function index()
    {
        // $user = new User;
        // $user->fullname = 'Demo';
        // $user->email = 'jrizky.jonathan@gmail.com';
        // $user->password = Hash::make('123456');
        // $user->status = 1;
        // $user->admin = 1;
        // $user->photo = "a";
        // $user->save();

        return view('login');
    }

    public function login(Request $request)
    {
        $email = $request->input('email');
        $data = [
            'email' => $request->input('email'),
            'password' => $request->input('password'),
        ];
        $agent = new Agent();
        $device = [
            'platform' => $agent->platform(),
            'browser' => $agent->browser(),
            'browser_version' => $agent->version($agent->browser()),
            'device' => $agent->device(),
            'mobile' => $agent->isMobile(),
            'mobile_version' => $agent->version($agent->isMobile())
        ];
        $device = json_encode($device);

        if (Auth::Attempt($data)) {
            if (Auth::user()->status === false) {
                $this->insert('tbl_login', [
                    'email' => $email,
                    'login' => false,
                    'device' => $device,
                    'login_at' => date('Y-m-d H:i:s'),
                    'ip_visitor' => $_SERVER['REMOTE_ADDR']
                ]);
                Session::flash('error', 'User Tidak Aktif');
                return redirect('/');
            }
            $this->insert('tbl_login', [
                'email' => $email,
                'login' => true,
                'device' => $device,
                'login_at' => date('Y-m-d H:i:s'),
                'ip_visitor' => $_SERVER['REMOTE_ADDR']
            ]);
            return redirect('GPRO001');
        } else {
            $this->insert('tbl_login', [
                'email' => $email,
                'login' => false,
                'device' => $device,
                'login_at' => date('Y-m-d H:i:s'),
                'ip_visitor' => $_SERVER['REMOTE_ADDR']
            ]);
            Session::flash('error', 'Email atau Password Salah');
            return redirect('/');
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}
