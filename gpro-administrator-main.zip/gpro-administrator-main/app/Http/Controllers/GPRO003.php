<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Hash;

class GPRO003 extends Controller
{
    public function index()
    {
        return view('gpro003.index');
    }

    public function getData()
    {
        $data = DB::select("
            select * from tbl_user_admins
        ");
        return DataTables::of($data)->make(true);
    }

    public function create()
    {
        return view('gpro003.create');
    }

    public function store(Request $request)
    {
        User::create([
            'fullname' => $request->fullname,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'status' => $request->status,
            'admin' => $request->admin,
            'photo' => "",
        ]);
        Session::flash('insert', 'Data Berhasil Disimpan');
        return redirect('GPRO003');
    }

    public function edit($id)
    {
        $data = User::find($id);
        return view('gpro003.edit',compact('data'));
    }

    public function update(Request $request,$id)
    {
        User::where('id',$id)->update([
            'fullname' => $request->fullname,
            'email' => $request->email,
            'status' => $request->status,
            'admin' => $request->admin,
        ]);
        Session::flash('update', 'Data Berhasil DiUpdate');
        return redirect('GPRO003');
    }

    public function destroy($id)
    {
        $data = User::find($id);
        $data->delete();
        Session::flash('delete', 'Data Berhasil Dihapus');
        return redirect('GPRO003');
    }
}
