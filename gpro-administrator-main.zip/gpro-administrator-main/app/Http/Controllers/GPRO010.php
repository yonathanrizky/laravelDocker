<?php

namespace App\Http\Controllers;

use App\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Yajra\DataTables\DataTables;

class GPRO010 extends Controller
{
    public function index()
    {
        return view('gpro010.index');
    }

    public function getData()
    {
        $data = DB::select("
        select id, prognm,menu,icon,admin from tbl_menus
        ");
        return DataTables::of($data)->make(true);
    }

    public function create()
    {
        return view('gpro010.create');
    }

    public function store(Request $request)
    {
        Menu::create([
            'prognm' => $request->prognm,
            'menu' => $request->menu,
            'icon' => $request->icon,
            'admin' => $request->admin,
        ]);
        Session::flash('insert', 'Data Berhasil Disimpan');
        return redirect('GPRO010');
    }

    public function edit($id)
    {
        $data = Menu::find($id);
        return view('gpro010.edit',compact('data'));
    }

    public function update(Request $request,$id)
    {
        Menu::where('id',$id)->update([
            'prognm' => $request->prognm,
            'menu' => $request->menu,
            'icon' => $request->icon,
            'admin' => $request->admin,
        ]);
        Session::flash('update', 'Data Berhasil DiUpdate');
        return redirect('GPRO010');
    }

    public function destroy($id)
    {
        $data = Menu::find($id);
        $data->delete();
        Session::flash('delete', 'Data Berhasil Dihapus');
        return redirect('GPRO010');
    }
}