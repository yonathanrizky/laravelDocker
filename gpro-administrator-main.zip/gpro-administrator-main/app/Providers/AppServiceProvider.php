<?php

namespace App\Providers;

use App\Menu;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $menuItems = Menu::all();

        // $menuItems = [
        //     [
        //         'prognm' => 'GPRO004',
        //         'menu' => 'GPRO004',
        //         'icon' => 'fas fa-fw fa-briefcase'
        //     ]
        // ];

        view()->share('menuItems', $menuItems);
    }
}
