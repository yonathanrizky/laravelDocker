<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TempCareerAdvisor extends Model
{
    protected $table = 'temp_career_advisor';
    protected $guarded = ['id'];
}
