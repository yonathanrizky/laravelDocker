<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CareerAdvisor extends Model
{
    protected $table = 'tbl_career_advisors';
    protected $guarded = ['id'];
}
