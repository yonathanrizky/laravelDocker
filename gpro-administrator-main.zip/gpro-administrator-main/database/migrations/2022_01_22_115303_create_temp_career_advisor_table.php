<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTempCareerAdvisorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('temp_career_advisor', function (Blueprint $table) {
            $table->id();
            $table->integer('career_advisor_id')->nullable();
            $table->integer('sub_categories_id');
            $table->text('description');
            $table->text('become_desc');
            $table->float('sallary_start', 17, 2);
            $table->float('sallary_end', 17, 2);
            $table->text('photo_banner');
            $table->jsonb('job_desc')->nullable();
            $table->jsonb('education')->nullable();
            $table->jsonb('training')->nullable();
            $table->jsonb('license')->nullable();
            $table->text('unique_id')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('temp_career_advisor');
    }
}
