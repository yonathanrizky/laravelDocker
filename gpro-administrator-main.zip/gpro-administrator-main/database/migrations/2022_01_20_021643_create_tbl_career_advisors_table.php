<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTblCareerAdvisorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_career_advisors', function (Blueprint $table) {
            $table->id();
            $table->integer('sub_categories_id')->unique();
            $table->text('description');
            $table->text('become_desc');
            $table->float('sallary_start', 17, 2);
            $table->float('sallary_end', 17, 2);
            $table->text('photo_banner');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_career_advisors');
    }
}
