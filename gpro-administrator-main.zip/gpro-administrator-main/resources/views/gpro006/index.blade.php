@extends('layouts.master')
@section('content')
    <div class="float-right">
        <div class="row">
            <div class="col-md-12 mb-3 float-right">
                <button type="button" class='btn btn-primary btn-circle' data-toggle="modal"
                    data-target="#m-import-category"><i class="fas fa-file-upload"></i></button>
                <a href={{ url('GPRO006/export') }} class='btn btn-info btn-circle'><i
                        class="fas fa-file-download"></i></a>
                <a href={{ url('GPRO006/create') }} class='btn btn-success btn-circle'><i class="fas fa-plus"></i></a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table id="table-category" class="table table-bordered dataTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th>Pilihan</th>
                </tr>
            </thead>
        </table>
    </div>

    <div class="modal fade" id="m-import-category" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Import Sub Kategori Pekerjaan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12">
                            <div class="card o-hidden border-0 shadow-lg">
                                <div class="card-body p-0">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="p-5">
                                                <form class="input" action="{{ url('/GPRO006/import') }}"
                                                    method="POST" enctype="multipart/form-data">
                                                    @csrf
                                                    <div class="form-group">
                                                        <label>File</label>
                                                        <hr>
                                                        <input class="form-control-file form-control-user" type="file"
                                                            name="file">
                                                    </div>
                                                    <hr>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-user btn-block mt-2" data-dismiss="modal">Tutup</button>
                    <button class="btn btn-primary btn-user btn-block mt-2 btn-submit-education">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('js-content')
    <script type="text/javascript">
        $(document).ready(function() {
            $('#table-category').DataTable({
                processing: true,
                serverSide: true,
                ajax: '{{ url('GPRO006/getData') }}',
                columns: [{
                        width: '8%',
                        render: function(data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        },
                    },
                    {
                        data: 'category'
                    },
                    {
                        data: 'description'
                    },
                    {
                        width: '10%',
                        render: function(data, type, row) {
                            var s =
                                `<a href='GPRO006/edit/${row.id}' class='btn btn-success btn-circle'><i class="fas fa-clipboard"></i></a>
                            <a href='GPRO006/delete/${row.id}' class='btn btn-danger btn-circle'><i class='fas fa-trash'></i></a>
                            `;
                            return s;
                        },
                    }
                ],
            });
        });
    </script>
@endsection
