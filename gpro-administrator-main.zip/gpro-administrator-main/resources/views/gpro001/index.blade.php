@extends('layouts.master')
@section('content')
    <h1 class="h3 mb-4 text-gray-800">Selamat Datang {{ Auth::user()->fullname }}</h1>
@endsection
