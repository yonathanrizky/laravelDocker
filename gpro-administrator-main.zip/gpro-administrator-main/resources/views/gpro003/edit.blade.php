@extends('layouts.master')
@section('content')
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="card o-hidden border-0 shadow-lg">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-left">
                                <h1 class="h4 text-gray-900 mb-4">Data Admin</h1>
                            </div>
                            @if (session('error'))
                            <div class="alert alert-danger">
                                <b>Opps!</b> {{ session('error') }}
                            </div>
                            @endif
                            <form class="input" action="{{ url('/GPRO003/update',$data->id) }}" method="POST" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                {{ method_field('PATCH') }}
                                <div class="row">
                                    <div class="form-group col-lg-6">
                                        <label>Fullname</label>
                                        <input type="text" name="fullname" value="{{$data->fullname}}" class="form-control form-control-input">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Email</label>
                                        <input type="email" name="email" value="{{$data->email}}" class="form-control form-control-input">
                                    </div>

                                    <div class="form-group col-lg-6">
                                        <label>Status</label>
                                        <select class="form-control" name="status" id="is_status">
                                            <option value="true">True</option>
                                            <option value="false">False</option>
                                        </select>
                                        <input type="hidden" id="is_status_text" class="form-control" value="{{ $data->status }}">
                                    </div>
                                    <div class="form-group col-lg-6">
                                        <label>Admin</label>
                                        <select class="form-control" name="admin" id="is_admin">
                                            <option value="true">True</option>
                                            <option value="false">False</option>
                                        </select>
                                        <input type="hidden" id="is_admin_text" class="form-control" value="{{ $data->admin }}">
                                    </div>
                                    <div class="col-md-12 col-xs-12 form-group">
                                        <input type="checkbox" name="checkpass" value="1" id="checkpass"><label> Ceklis bila ingin mengganti password</label>
                                    </div>
                                    <div class="col-md-12 col-xs-12 form-group" id="cpassword">
                                    </div>
                                </div>

                                <div class="float-right mt-3">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary btn-user btn-block mt-2">Simpan</button>
                                        </div>
                                    </div>
                                    <br><br>
                                </div>
                            </form>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('js-custom')
<script type="text/javascript">
    $(document).ready(function() {
        var is_status_text = $('#is_status_text').val();
        $('#is_status').val(is_status_text);
        var is_admin_text = $('#is_admin_text').val();
        $('#is_admin').val(is_admin_text);
    });

    $('#checkpass').change(function() {
        if ($(this).is(':checked')) {
            $("#cpassword").append('<label>Password</label>\n' +
                '<input type="password" name="password" class="form-control" autocomplete="new-password" placeholder="Masukkan Password">' +
                '<label>Retype Password</label>' +
                '<input type="password" name="repassword" class="form-control" placeholder="Masukkan Re-type Password">');
        } else {
            $("#cpassword").html("");
        }
    });
</script>
@endsection