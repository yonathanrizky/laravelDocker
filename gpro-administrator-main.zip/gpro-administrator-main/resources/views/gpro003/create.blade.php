@extends('layouts.master')
@section('content')
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="card o-hidden border-0 shadow-lg">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-left">
                                <h1 class="h4 text-gray-900 mb-4">Data Admin</h1>
                            </div>
                            @if (session('error'))
                            <div class="alert alert-danger">
                                <b>Opps!</b> {{ session('error') }}
                            </div>
                            @endif
                            <form class="input" action="{{ url('/GPRO003/store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                <div class="form-group col-lg-6">
                                    <label>Fullname</label>
                                    <input type="text" name="fullname" class="form-control form-control-input">
                                </div>
                                <div class="form-group col-lg-6">
                                    <label>Email</label>
                                    <input type="email" name="email" class="form-control form-control-input">
                                </div>
                                <div class="form-group col-lg-6">
                                    <label>Password</label>
                                    <input type="password" name="re-password" class="form-control form-control-input">
                                </div>
                                <div class="form-group col-lg-6">
                                    <label>Re-Password</label>
                                    <input type="password" name="password" class="form-control form-control-input">
                                </div>
                                <div class="form-group col-lg-6">
                                    <label>Status</label>
                                    <select class="form-control" name="status">
                                        <option value="true">True</option>
                                        <option value="false">False</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label>Admin</label>
                                    <select class="form-control" name="admin">
                                        <option value="true">True</option>
                                        <option value="false">False</option>
                                    </select>
                                </div>
                                </div>
                             
                                <div class="float-right mt-3">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary btn-user btn-block mt-2">Simpan</button>
                                        </div>
                                    </div>
                                    <br><br>
                                </div>
                            </form>
                            <hr>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection