@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-left">
                                    <h1 class="h4 text-gray-900 mb-4">Download Template Import Career Advisor</h1>
                                </div>
                                <form class="input" action="{{ url('/GPRO007/export') }}" method="POST">
                                    @csrf

                                    <div class="form-group">
                                        <label>Pilihan</label>
                                        <select class="form-control form-control-select" name="type">
                                            <option value="career" class="form-control">Career Advisor</option>
                                            <option value="detail" class="form-control">Detail Career Advisor</option>
                                        </select>
                                    </div>
                                    <div class="float-right mt-3">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <button type="submit"
                                                    class="btn btn-success btn-user btn-block mt-2 mb-5">Download</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-left">
                                    <h1 class="h4 text-gray-900 mb-4">Import Career Advisor</h1>
                                </div>
                                <form class="input" action="{{ url('/GPRO007/import') }}" method="POST"
                                    enctype="multipart/form-data">
                                    @csrf

                                    <div class="form-group">
                                        <label>Pilihan</label>
                                        <select class="form-control form-control-select" name="type">
                                            <option value="career" class="form-control">Career Advisor</option>
                                            <option value="detail" class="form-control">Detail Career Advisor</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>File</label>
                                        <hr>
                                        <input class="form-control-file form-control-user" type="file" name="file">
                                    </div>
                                    <div class="float-right mt-3">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <button type="submit"
                                                    class="btn btn-primary btn-user btn-block mt-2 mb-5">Proses</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
