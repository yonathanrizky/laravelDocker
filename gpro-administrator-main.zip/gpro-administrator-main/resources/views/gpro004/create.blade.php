@extends('layouts.master')
@section('js-content')
    <script>
        $(document).ready(function() {
            // localStorage.removeItem("uniqueId");
            // let uniqueId = new Date().getTime();
            // localStorage.setItem('uniqueId', uniqueId);
            // document.getElementById("uniqueId").value = uniqueId;
        });
    </script>
@endsection
@section('content')
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <div class="text-left">
                                    <h1 class="h4 text-gray-900 mb-4">Career Advisor</h1>
                                </div>
                                <form class="input" action="{{ url('/GPRO004/next') }}" method="POST"
                                    enctype="multipart/form-data">
                                    @csrf
                                    <input hidden value="{{ $uniqueId }}" id="uniqueId" name="uniqueId">
                                    <input hidden value="{{ $activity }}" id="activity" name="activity">
                                    <input hidden value="{{ isset($id) ? $id : '' }}" id="id" name="id">
                                    @include('gpro004.partials.layout')

                                    <div class="float-right mt-3">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <button type="submit"
                                                    class="btn btn-primary btn-user btn-block mt-2 mb-5">Selanjutnya</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
