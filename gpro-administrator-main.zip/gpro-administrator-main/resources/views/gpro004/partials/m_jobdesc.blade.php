<div class="modal fade" id="m-jobdesc" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Data Job Desc</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form>
                    @csrf
                    <input hidden value="{{ $uniqueId }}" id="uniqueId" name="uniqueId">
                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea rows="5" class="form-control form-control-input" required="" id="description"
                            oninvalid="this.setCustomValidity(`${messageValidation}`)" name="description"></textarea>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-user btn-block mt-2"
                    data-dismiss="modal">Close</button>
                <button class="btn btn-primary btn-user btn-block mt-2 btn-submit">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
@section('js-modal')
    <script src="{{ asset('assets/vendor/jquery/jquery.min.js') }}"></script>
    <script type="text/javascript">
        $(".btn-submit").click(function(e) {

            e.preventDefault();

            let uniqueId = $("input[name=uniqueId]").val();
            let description = $('textarea#description').val();
            $.ajax({
                type: 'POST',
                url: "{{ route('add-job-desc') }}",
                data: {
                    _token: "{{ csrf_token() }}",
                    uniqueId: uniqueId,
                    description: description
                },
                success: function(data) {
                    $('#m-jobdesc').modal('hide');
                    location.reload();
                }
            });
        });
    </script>
@endsection
