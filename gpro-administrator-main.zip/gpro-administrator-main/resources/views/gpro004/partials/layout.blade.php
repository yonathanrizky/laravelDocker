<div class="form-group">
    <label>Kategori</label>
    <select class="form-control form-control-select" name="sub_categories_id">
        @foreach ($subCategories as $value)
            <option value="{{ $value->id }}" class="form-control"
                {{ isset($data->sub_categories_id) ? ($value->id == $data->sub_categories_id ? 'selected' : '') : '' }}>
                {{ $value->description }}</option>
        @endforeach
    </select>
</div>
<div class="form-group">
    <label>Deskripsi</label>
    <textarea rows="5" class="form-control form-control-input"
        name="description">{{ isset($data) ? $data->description : '' }}</textarea>
</div>
<div class="form-group">
    <label>Become Desc</label>
    <textarea rows="5" class="form-control form-control-input"
        name="become_desc">{{ isset($data) ? $data->become_desc : '' }}</textarea>
</div>
<label>Sallary</label>
<div class="row">
    <div class="col-lg-6">
        <div class="form-group">
            <input type="number" class="form-control form-control-input" id="exampleInputPassword" placeholder="10000"
                name="sallary_start" value="{{ isset($data) ? $data->sallary_start : '' }}">
        </div>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <input type="number" class="form-control form-control-input" id="exampleInputPassword" placeholder="20000"
                name="sallary_end" value="{{ isset($data) ? $data->sallary_end : '' }}">
        </div>
    </div>
</div>
<div class="form-group">
    <label>Link Foto Banner</label>
    <input class="form-control form-control-input" name="photo_banner"
        value="{{ isset($data) ? $data->photo_banner : '' }}">
</div>
