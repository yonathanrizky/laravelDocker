@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-xl-12 col-lg-12 col-md-12">
            <div class="card o-hidden border-0 shadow-lg">
                <div class="card-body p-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="p-5">
                                <form method="post" action="{{ route('GPRO004/store') }}">
                                    @csrf
                                    <input value="{{ $uniqueId }}" hidden name="uniqueId">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="text-center text-gray-900">Data Job Desc</p>
                                            <div class="row float-right">
                                                <div class="col-md-6 mb-3">
                                                    <button type="button" class='btn btn-success btn-circle'
                                                        data-toggle="modal" data-target="#m-jobdesc"><i
                                                            class="fas fa-plus"></i></button>
                                                </div>
                                            </div>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Deskripsi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if ($jobDesc)
                                                        @foreach ($jobDesc as $value)
                                                            <tr>
                                                                <td>
                                                                    <a href="javascript:void(0)"
                                                                        class="btn btn-danger btn-circle"
                                                                        onclick="deleteJobDesc({{ $value['id'] }}, {{ $uniqueId }})"><i
                                                                            class='fas fa-trash'></i></a>
                                                                </td>
                                                                <td>{{ $value['description'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Tidak Ada Data</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-6">
                                            <p class="text-center text-gray-900">Data Sekolah</p>
                                            <div class="row float-right">
                                                <div class="col-md-6 mb-3">
                                                    <a href="#" class='btn btn-success btn-circle' data-toggle="modal"
                                                        data-target="#m-education"><i class="fas fa-plus"></i></a>
                                                </div>
                                            </div>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Pendidikan</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if ($education)
                                                        @foreach ($education as $value)
                                                            <tr>
                                                                <td>
                                                                    <a href="javascript:void(0)"
                                                                        class="btn btn-danger btn-circle"
                                                                        onclick="deleteEducation({{ $value['id'] }}, {{ $uniqueId }})"><i
                                                                            class='fas fa-trash'></i></a>
                                                                </td>
                                                                <td>{{ $value['description'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Tidak Ada Data</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <hr class="sidebar-divider d-none d-md-block">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="text-center text-gray-900">Data Training</p>
                                            <div class="row float-right">
                                                <div class="col-md-6 mb-3">
                                                    <a href="#" class='btn btn-success btn-circle' data-toggle="modal"
                                                        data-target="#m-training"><i class="fas fa-plus"></i></a>
                                                </div>
                                            </div>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Traning</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if ($training)
                                                        @foreach ($training as $value)
                                                            <tr>
                                                                <td>
                                                                    <a href="javascript:void(0)"
                                                                        class="btn btn-danger btn-circle"
                                                                        onclick="deleteTraining({{ $value['id'] }}, {{ $uniqueId }})"><i
                                                                            class='fas fa-trash'></i></a>
                                                                </td>
                                                                <td>{{ $value['description'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Tidak Ada Data</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="col-md-6">
                                            <p class="text-center text-gray-900">Data Lisensi</p>
                                            <div class="row float-right">
                                                <div class="col-md-6 mb-3">
                                                    <a href="#" class='btn btn-success btn-circle' data-toggle="modal"
                                                        data-target="#m-license"><i class="fas fa-plus"></i></a>
                                                </div>
                                            </div>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Lisensi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if ($license)
                                                        @foreach ($license as $value)
                                                            <tr>
                                                                <td>
                                                                    <a href="javascript:void(0)"
                                                                        class="btn btn-danger btn-circle"
                                                                        onclick="deleteLicense({{ $value['id'] }}, {{ $uniqueId }})"><i
                                                                            class='fas fa-trash'></i></a>
                                                                </td>
                                                                <td>{{ $value['description'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Tidak Ada Data</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <hr class="sidebar-divider d-none d-md-block">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="text-center text-gray-900">Data Experience</p>
                                            <div class="row float-right">
                                                <div class="col-md-6 mb-3">
                                                    <a href="#" class='btn btn-success btn-circle' data-toggle="modal"
                                                        data-target="#m-experience"><i class="fas fa-plus"></i></a>
                                                </div>
                                            </div>
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Experience</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @if ($experience)
                                                        @foreach ($experience as $value)
                                                            <tr>
                                                                <td>
                                                                    <a href="javascript:void(0)"
                                                                        class="btn btn-danger btn-circle"
                                                                        onclick="deleteExperience({{ $value['id'] }}, {{ $uniqueId }})"><i
                                                                            class='fas fa-trash'></i></a>
                                                                </td>
                                                                <td>{{ $value['description'] }}</td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td>#</td>
                                                            <td>Tidak Ada Data</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <hr class="sidebar-divider d-none d-md-block">
                                    <div class="float-right mt-3">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <button type="submit"
                                                    class="btn btn-primary btn-user btn-block mt-2 mb-5">Simpan</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- Modal --}}
    @include('gpro004.partials.m_jobdesc')
    @include('gpro004.partials.m_education')
    @include('gpro004.partials.m_training')
    @include('gpro004.partials.m_license')
    @include('gpro004.partials.m_experience')
    @yield('js-modal')
@endsection
@section('js-content')
    <script>
        function deleteJobDesc(id, uniqueId) {
            let url = `{{ url('GPRO004/delete-job-desc/${id}/${uniqueId}') }}`;
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    location.reload();
                }
            });
        }

        function deleteEducation(id, uniqueId) {
            let url = `{{ url('GPRO004/delete-education/${id}/${uniqueId}') }}`;
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    location.reload();
                }
            });
        }

        function deleteTraining(id, uniqueId) {
            let url = `{{ url('GPRO004/delete-training/${id}/${uniqueId}') }}`;
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    location.reload();
                }
            });
        }

        function deleteLicense(id, uniqueId) {
            let url = `{{ url('GPRO004/delete-license/${id}/${uniqueId}') }}`;
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    location.reload();
                }
            });
        }

        function deleteExperience(id, uniqueId) {
            let url = `{{ url('GPRO004/delete-experience/${id}/${uniqueId}') }}`;
            $.ajax({
                type: 'GET',
                url: url,
                success: function(data) {
                    location.reload();
                }
            });
        }
    </script>
@endsection
